# Color Token Usage Across Cartzi Components

## Primary Colors (`--primary`, `--primary-foreground`)

### Text Colors (`text-primary`)
- **Logo.jsx**: Main logo text
- **Button.jsx**: Link variant buttons
- **Input.jsx**: Text selection color

### Background Colors (`bg-primary`)
- **ProductCard.jsx**: Sale badge background
- **Button.jsx**: Default button background
- **Badge.jsx**: Primary badge variant
- **Tooltip.jsx**: Tooltip background
- **Input.jsx**: Text selection background

### Foreground Colors (`text-primary-foreground`)
- **ProductCard.jsx**: Sale badge text
- **Button.jsx**: Default button text
- **Badge.jsx**: Primary badge text
- **Tooltip.jsx**: Tooltip text
- **Input.jsx**: Selected text color

---

## Secondary Colors (`--secondary`, `--secondary-foreground`)

### Background Colors (`bg-secondary`)
- **Button.jsx**: Secondary button variant
- **Badge.jsx**: Secondary badge variant

### Foreground Colors (`text-secondary-foreground`)
- **Button.jsx**: Secondary button text
- **Badge.jsx**: Secondary badge text

---

## Accent Colors (`--accent`, `--accent-foreground`)

### Background Colors (`bg-accent`)
- **Button.jsx**: Ghost and outline button hover states
- **Badge.jsx**: Default badge hover state
- **Command.jsx**: Selected item background
- **Dialog.jsx**: Close button hover state
- **Skeleton.jsx**: Skeleton loading background

### Text Colors (`text-accent`)
- **Button.jsx**: Ghost button hover text
- **Badge.jsx**: Default badge hover text

### Foreground Colors (`text-accent-foreground`)
- **Button.jsx**: Ghost button hover text
- **Badge.jsx**: Default badge hover text
- **Command.jsx**: Selected item text

---

## Muted Colors (`--muted`, `--muted-foreground`)

### Background Colors (`bg-muted`)
- **Tabs.jsx**: Tab list background
- **Table.jsx**: Table header and row hover states

### Text Colors (`text-muted-foreground`)
- **Sidebar.jsx**: Inactive menu items
- **SearchBar.jsx**: Search icon
- **NoProducts.jsx**: Package icon and description text
- **MobileMenu.jsx**: Menu icon
- **HeaderMenu.jsx**: Inactive navigation items
- **Header.jsx**: Orders icon
- **CartIcon.jsx**: Cart icon
- **FormattedPrice.jsx**: Strikethrough price text
- **UI Components**: Various form elements, tooltips, and interactive elements

---

## Destructive Colors (`--destructive`, `--destructive-foreground`)

### Background Colors (`bg-destructive`)
- **Button.jsx**: Destructive button variant
- **Badge.jsx**: Destructive badge variant

### Border Colors (`border-destructive`)
- **Button.jsx**: Invalid state borders
- **Badge.jsx**: Invalid state borders
- **Input.jsx**: Invalid state borders
- **Textarea.jsx**: Invalid state borders

### Ring Colors (`ring-destructive`)
- **Button.jsx**: Focus and invalid states
- **Badge.jsx**: Focus and invalid states
- **Input.jsx**: Invalid state focus rings
- **Textarea.jsx**: Invalid state focus rings

---

## Base Colors

### Background (`--background`)
- **NoProducts.jsx**: Container background
- **Sidebar.jsx**: Sidebar background
- **Dialog.jsx**: Dialog background
- **Tabs.jsx**: Active tab background

### Foreground (`--foreground`)
- **Header.jsx**: Header text
- **FormattedPrice.jsx**: Price text
- **NoProducts.jsx**: Heading text
- **Sidebar.jsx**: Active menu items
- **HeaderMenu.jsx**: Active navigation items
- **UI Components**: Various text elements

### Card (`--card`, `--card-foreground`)
- **Card.jsx**: Card component background and text

### Border (`--border`)
- **Header.jsx**: Header bottom border
- **NoProducts.jsx**: Container border

### Input (`--input`)
- **Input.jsx**: Input field borders
- **Button.jsx**: Button borders in dark mode
- **Tabs.jsx**: Tab borders in dark mode

### Ring (`--ring`)
- **Input.jsx**: Focus rings
- **Textarea.jsx**: Focus rings
- **Tabs.jsx**: Focus rings

---

## Usage Patterns

### Most Used Colors:
1. **Muted Foreground** - Used extensively for secondary text and icons
2. **Primary** - Used for main brand elements and CTAs
3. **Foreground** - Used for main text content
4. **Accent** - Used for hover states and interactive elements

### Component-Specific Usage:
- **ProductCard.jsx**: Uses primary for sale badges
- **Logo.jsx**: Uses primary for brand identity
- **Header Components**: Use muted-foreground for inactive states
- **UI Components**: Use various tokens for different states and variants

### Interactive States:
- **Hover**: Usually transitions from muted-foreground to foreground
- **Active**: Uses primary or accent colors
- **Focus**: Uses ring colors
- **Invalid**: Uses destructive colors
